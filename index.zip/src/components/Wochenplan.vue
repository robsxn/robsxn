<template>
  <div class="Wochenplan">
  <h1>Wochenplan</h1>
  <iframe src="http://www.bistroessart-speiseplan.de/splan/public/pdf/pdfforloc/location/f7177163c833dff4b38fc8d2872f1ec6" width="94%" height="600px" padding-left="4%"></iframe>
  </div>
</template>

<script>
export default {
  name: 'Wochenplan',
  data () {
    return {}
        }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.Wochenplan{
padding-left:5%

}
</style>
