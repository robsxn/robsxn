<template>
  <div class="Lieferanten">
  <h1>Lieferanten</h1>
  </div>
</template>

<script>
export default {
  name: 'Lieferanten',
  data () {
    return {
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
