/* var vm = new Vue({
    el: '#app',
    data: {
        Datum: new Date().toLocaleDateString(),
        Tag: new Date().getDay(),
        wochentag: ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'],


    

    },


    computed : {
                   message:function(){return(this.wochentag[this.Tag -1])}
                   
                   
            
    }
}) */